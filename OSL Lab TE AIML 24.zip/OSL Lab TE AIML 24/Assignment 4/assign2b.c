/* 
Name : 
Class : 
RollNO :- 
Problem Statement: Process control system calls: The demonstration of FORK, EXECVE and WAIT system calls
along with zombie and orphan states.

b. Implement the C program in which main program accepts an array. Main program uses the FORK system
call to create a new process called a child process. Parent process sorts an array and passes the sorted array
to child process through the command line arguments of EXECVE system call. The child process uses EXECVE
system call to load new program which display array in reverse order.
*/


#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>
		
void bass(int arr[10],int n)
{
	int i,j,temp;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(arr[j]>arr[j+1])
			{
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	printf("\n Ascending Order \n");
	for(i=0;i<n;i++)
		printf("\t%d",arr[i]);
	printf("\n\n\n");
}

void bdsc(int arr[10],int n)
{
	int i,j,temp;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(arr[j]<arr[j+1])
			{
				temp=arr[j];  
				arr[j]=arr[j+1];  
				arr[j+1]=temp; 	
			}
		}
	}
	printf("\n Descending Sorting \n\n");
	for(i=0;i<n;i++)
		printf("\t%d",arr[i]);
	printf("\n\n\n");
	
}
void forkeg()
{
 	int arr[25],arr1[25],n,i;
 	printf("\nEnter the no of values in array");
 	scanf("%d",&n);
 	printf("\nEnter the array elements");
 	for(i=0;i<n;i++)
    		scanf("%d",&arr[i]);
 	int pid=fork();
  	if(pid==0)
   	{
      		sleep(10);
      		printf("\nchild process\n");
      		printf("child process id=%d\n",getpid());
      		bdsc(arr,n);
       		printf("\nElements Sorted Using Bubble Sort");
     		printf("\n");
       		for(i=0;i<n;i++)
    			printf("%d,",arr[i]);
    		printf("\n");
     		printf("\nparent process id=%d\n",getppid());
     		system("ps -x");
       }    
      else
       {
     		printf("\nparent process\n");
     		printf("\nparent process id=%d\n",getppid());
	 	bass(arr,n);	      
		printf("Elements Sorted Using Bubble Sort");
     		printf("\n");
      		for(i=0;i<n;i++)
    			printf("%d,",arr[i]);
    		printf("\n\n\n"); 
      } 
 }     
 int main()
 {
   	forkeg();
   	return 0;
 }  
/*OUTPUT:
samarth@samarth-OptiPlex-7010:~/OS Lab/Assignment 2$ gcc assign2b.c 
samarth@samarth-OptiPlex-7010:~/OS Lab/Assignment 2$ ./a.out

Enter the no of values in array5

Enter the array elements4 3 2 5 1

parent process

parent process id=35806

 Ascending Order 
	1	2	3	4	5


Elements Sorted Using Bubble Sort
1,2,3,4,5,

samarth@samarth-OptiPlex-7010:~/OS Lab/Assignment 2$
samarth@samarth-OptiPlex-7010:~/OS Lab/Assignment 2$ 
child process
child process id=3815

 Descending Sorting 

	5	4	3	2	1



Elements Sorted Using Bubble Sort
5,4,3,2,1,

parent process id=1327
    PID TTY      STAT   TIME COMMAND
   1327 ?        Ss     0:00 /lib/systemd/systemd --user
   1328 ?        S      0:00 (sd-pam)
   1334 ?        S<sl   0:00 /usr/bin/pipewire
   1335 ?        Ssl    0:00 /usr/bin/pipewire-media-session
   1336 ?        S<sl   0:00 /usr/bin/pulseaudio --daemonize=no --log-target=jou
   1350 ?        Ss     0:00 /usr/bin/dbus-daemon --session --address=systemd: -
   1355 ?        Ssl    0:00 /usr/libexec/gvfsd
   1357 ?        Sl     0:00 /usr/bin/gnome-keyring-daemon --daemonize --login
   1371 ?        Sl     0:00 /usr/libexec/gvfsd-fuse /run/user/1000/gvfs -f
   1379 ?        Ssl    0:00 /usr/libexec/xdg-document-portal
   1383 ?        Ssl    0:00 /usr/libexec/xdg-permission-store
   1401 ?        SNsl   0:00 /usr/libexec/tracker-miner-fs-3
   1414 tty2     Ssl+   0:00 /usr/libexec/gdm-wayland-session env GNOME_SHELL_SE
   1417 tty2     Sl+    0:00 /usr/libexec/gnome-session-binary --session=ubuntu
   1425 ?        Ssl    0:00 /usr/libexec/gvfs-udisks2-volume-monitor
   1462 ?        Ssl    0:00 /usr/libexec/gvfs-gphoto2-volume-monitor
   1467 ?        Ssl    0:00 /usr/libexec/gvfs-afc-volume-monitor
   1479 ?        Ssl    0:00 /usr/libexec/gnome-session-ctl --monitor
   1480 ?        Ssl    0:00 /usr/libexec/gvfs-mtp-volume-monitor
   1492 ?        Ssl    0:00 /usr/libexec/gvfs-goa-volume-monitor
   1497 ?        Sl     0:00 /usr/libexec/goa-daemon
   1499 ?        Ssl    0:00 /usr/libexec/gnome-session-binary --systemd-service
   1514 ?        Sl     0:00 /usr/libexec/goa-identity-service
   1533 ?        Sl     0:00 /usr/libexec/at-spi-bus-launcher --launch-immediate
   1542 ?        S      0:00 /usr/bin/dbus-daemon --config-file=/usr/share/defau
   1543 ?        Rsl    0:25 /usr/bin/gnome-shell
   1596 ?        Sl     0:00 /usr/libexec/gnome-shell-calendar-server
   1602 ?        Ssl    0:00 /usr/libexec/evolution-source-registry
   1610 ?        Ssl    0:00 /usr/libexec/dconf-service
   1615 ?        Ssl    0:00 /usr/libexec/evolution-calendar-factory
   1624 ?        Ssl    0:00 /usr/libexec/evolution-addressbook-factory
   1640 ?        Sl     0:11 /usr/bin/nautilus --gapplication-service
   1641 ?        Sl     0:00 /usr/libexec/gvfsd-trash --spawner :1.2 /org/gtk/gv
   1648 ?        Sl     0:00 /usr/bin/gjs /usr/share/gnome-shell/org.gnome.Shell
   1651 ?        Sl     0:00 /usr/libexec/at-spi2-registryd --use-gnome-session
   1666 ?        Ss     0:00 sh -c /usr/bin/ibus-daemon --panel disable $([ "$XD
   1667 ?        Ssl    0:00 /usr/libexec/gsd-a11y-settings
   1669 ?        Ssl    0:00 /usr/libexec/gsd-color
   1673 ?        Sl     0:00 /usr/bin/ibus-daemon --panel disable
   1676 ?        Ssl    0:00 /usr/libexec/gsd-datetime
   1677 ?        Ssl    0:00 /usr/libexec/gsd-housekeeping
   1678 ?        Ssl    0:00 /usr/libexec/gsd-keyboard
   1679 ?        Ssl    0:00 /usr/libexec/gsd-media-keys
   1681 ?        Ssl    0:00 /usr/libexec/gsd-power
   1683 ?        Ssl    0:00 /usr/libexec/gsd-print-notifications
   1691 ?        Ssl    0:00 /usr/libexec/gsd-rfkill
   1700 ?        Ssl    0:00 /usr/libexec/gsd-screensaver-proxy
   1706 ?        Ssl    0:00 /usr/libexec/gsd-sharing
   1707 ?        Ssl    0:00 /usr/libexec/gsd-smartcard
   1718 ?        Ssl    0:00 /usr/libexec/gsd-sound
   1720 ?        Ssl    0:00 /usr/libexec/gsd-wacom
   1750 ?        Sl     0:00 /usr/libexec/gsd-printer
   1765 ?        Sl     0:00 /usr/libexec/evolution-data-server/evolution-alarm-
   1772 ?        Sl     0:00 /usr/libexec/ibus-memconf
   1773 ?        Sl     0:01 /usr/libexec/ibus-extension-gtk3
   1780 ?        Sl     0:00 /usr/libexec/gsd-disk-utility-notify
   1788 ?        Sl     0:00 /usr/libexec/ibus-portal
   1835 ?        Sl     0:00 /usr/libexec/ibus-engine-simple
   1840 ?        Ssl    0:00 /usr/libexec/gvfsd-metadata
   1852 ?        Ssl    0:00 /usr/libexec/xdg-desktop-portal
   1866 ?        Ssl    0:01 /usr/libexec/xdg-desktop-portal-gnome
   1899 ?        Sl     0:00 /usr/bin/gjs /usr/share/gnome-shell/org.gnome.Scree
   1914 ?        Ss     0:00 /snap/snapd-desktop-integration/157/usr/bin/snapd-d
   1917 ?        Ssl    0:00 /usr/libexec/xdg-desktop-portal-gtk
   1998 ?        Sl     0:00 /snap/snapd-desktop-integration/157/usr/bin/snapd-d
   2008 ?        Sl     0:01 gjs /usr/share/gnome-shell/extensions/ding@rasterso
   2105 ?        Sl     0:44 /snap/firefox/4136/usr/lib/firefox/firefox
   2193 ?        Sl     0:00 update-notifier
   2300 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2317 ?        Sl     0:02 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2354 ?        Sl     0:00 /usr/bin/snap userd
   2506 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2847 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2853 ?        Sl     0:02 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2857 ?        Sl     0:23 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2886 ?        Sl     0:26 /snap/firefox/4136/usr/lib/firefox/firefox -content
   2997 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   3002 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   3080 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   3121 ?        Sl     0:00 /snap/firefox/4136/usr/lib/firefox/firefox -content
   3199 ?        Sl     0:02 /snap/firefox/4136/usr/lib/firefox/firefox -content
   3345 ?        Sl     0:00 /usr/libexec/gvfsd-network --spawner :1.2 /org/gtk/
   3370 ?        Sl     0:00 /usr/libexec/gvfsd-dnssd --spawner :1.2 /org/gtk/gv
   3670 ?        Sl     0:02 /usr/bin/gedit --gapplication-service
   3715 ?        Ssl    0:00 /usr/libexec/gnome-terminal-server
   3733 pts/0    Ss+    0:00 bash
   3815 pts/0    S      0:00 ./a.out
   3817 pts/0    S      0:00 sh -c ps -x
   3818 pts/0    R      0:00 ps -x 
*/
